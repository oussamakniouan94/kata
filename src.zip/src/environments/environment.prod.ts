export const environment = {
  production: true,
  apiUrl: 'https://fakestoreapi.com/products'
};