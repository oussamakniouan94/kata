export const environment = {
  production: false,
  apiUrl: 'https://fakestoreapi.com/products'
};